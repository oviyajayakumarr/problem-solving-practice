package Problem_solving_String;

public class RotationCheck {
    public static boolean isRotation(String s1, String s2) {
        if (s1.length() != s2.length()) return false;

        String combined = s1 + s1;
        return contains(combined, s2);
    }

    // Manual implementation of contains (no inbuilt method)
    public static boolean contains(String text, String pattern) {
        int n = text.length();
        int m = pattern.length();

        for (int i = 0; i <= n - m; i++) {
            int j = 0;
            while (j < m && text.charAt(i + j) == pattern.charAt(j)) {
                j++;
            }
            if (j == m) return true;
        }
        return false;
    }

    public static void main(String[] args) {
        System.out.println(isRotation("ABCD", "CDAB")); // true
        System.out.println(isRotation("ABCD", "ACBD")); // false
    }
}

