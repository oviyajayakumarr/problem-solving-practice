package Problem_solving_String;

public class StrStr {
    public static int strstr(String haystack, String needle) {
        if (needle.length() == 0) return 0;

        for (int i = 0; i <= haystack.length() - needle.length(); i++) {
            int j = 0;
            while (j < needle.length() && haystack.charAt(i + j) == needle.charAt(j)) {
                j++;
            }
            if (j == needle.length()) {
                return i;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        System.out.println(strstr("hello", "ll")); // 2
        System.out.println(strstr("aaaaa", "bba")); // -1
    }
}
