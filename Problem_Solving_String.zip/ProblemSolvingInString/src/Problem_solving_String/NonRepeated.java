package Problem_solving_String;

public class NonRepeated {

	    public static char firstUniqueChar(String str) {
	        for (int i = 0; i < str.length(); i++) {
	            char ch = str.charAt(i);
	            boolean isUnique = true;

	            for (int j = 0; j < str.length(); j++) {
	                if (i != j && ch == str.charAt(j)) {
	                    isUnique = false;
	                    break;
	                }
	            }

	            if (isUnique) {
	                return ch;
	            }
	        }
	        return '\0'; // No unique character
	    }

	    public static void main(String[] args) {
	        System.out.println("First unique character: " + firstUniqueChar("aabbcde")); // Output: c
	    }
	}


