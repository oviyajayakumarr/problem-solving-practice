package Problem_solving_String;

public class StringCompression {
    public static String compress(String str) {
        String result = "";
        int count = 1;

        for (int i = 0; i < str.length(); i++) {
            if (i < str.length() - 1 && str.charAt(i) == str.charAt(i + 1)) {
                count++;
            } else {
                result += str.charAt(i);
                if (count > 1) result += count;
                count = 1;
            }
        }

        return result;
    }

    public static void main(String[] args) {
        System.out.println(compress("aabbbcc")); // a2b3c2
        System.out.println(compress("abc"));     // abc
    }
}

