package Problem_solving_String;

public class RotationCheckNoConcat {
    public static boolean isRotation(String s1, String s2) {
        if (s1.length() != s2.length()) return false;

        for (int i = 0; i < s1.length(); i++) {
            boolean match = true;
            for (int j = 0; j < s2.length(); j++) {
                if (s1.charAt((i + j) % s1.length()) != s2.charAt(j)) {
                    match = false;
                    break;
                }
            }
            if (match) return true;
        }
        return false;
    }

    public static void main(String[] args) {
        System.out.println(isRotation("ABCD", "CDAB")); // true
        System.out.println(isRotation("ABCD", "ACBD")); // false
    }
}
