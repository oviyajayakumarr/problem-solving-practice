package Problem_solving_String;

public class BalancedBrackets {
    public static boolean isBalanced(String str) {
        char[] stack = new char[str.length()];
        int top = -1;

        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);

            if (ch == '(' || ch == '{' || ch == '[') {
                stack[++top] = ch;
            } else if (ch == ')' || ch == '}' || ch == ']') {
                if (top == -1) return false;
                char open = stack[top--];
                if (!matches(open, ch)) return false;
            }
        }

        return top == -1;
    }

    private static boolean matches(char open, char close) {
        return (open == '(' && close == ')') ||
               (open == '{' && close == '}') ||
               (open == '[' && close == ']');
    }

    public static void main(String[] args) {
        System.out.println(isBalanced("{[()]}")); // true
        System.out.println(isBalanced("{[(])}")); // false
    }
}
