package Problem_solving_String;

public class WordCount {
    public static void main(String[] args) {
        String input = "This is Java";
        int count = 0;
        boolean inWord = false;

        for (int i = 0; i < input.length(); i++) {
            char ch = input.charAt(i);
            if (ch != ' ' && !inWord) {
                count++;
                inWord = true;
            } else if (ch == ' ') {
                inWord = false;
            }
        }

        System.out.println("Word count: " + count);
    }
}
