package Problem_solving_String;

public class LongestWord {
    public static String longest(String str) {
        int maxLen = 0;
        String longest = "";
        String current = "";

        for (int i = 0; i <= str.length(); i++) {
            char ch = (i < str.length()) ? str.charAt(i) : ' ';
            if (ch != ' ') {
                current += ch;
            } else {
                if (current.length() > maxLen) {
                    maxLen = current.length();
                    longest = current;
                }
                current = "";
            }
        }

        return longest;
    }

    public static void main(String[] args) {
        System.out.println("Longest word: " + longest("The quick brown fox jumps over lazy dog"));
        // Output: "jumps"
    }
}

