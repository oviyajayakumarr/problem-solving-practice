package Problem_solving_String;

public class LongestCommonPrefix {
    public static String longestPrefix(String[] strs) {
        if (strs.length == 0) return "";

        for (int prefixLen = 0; prefixLen < strs[0].length(); prefixLen++) {
            char c = strs[0].charAt(prefixLen);

            for (int i = 1; i < strs.length; i++) {
                if (prefixLen >= strs[i].length() || strs[i].charAt(prefixLen) != c) {
                    return strs[0].substring(0, prefixLen);
                }
            }
        }
        return strs[0];
    }

    // Manual substring method (no inbuilt)
    private static String substring(String s, int start, int end) {
        String res = "";
        for (int i = start; i < end; i++) {
            res += s.charAt(i);
        }
        return res;
    }

    public static void main(String[] args) {
        String[] arr = {"flower", "flow", "flight"};
        System.out.println(longestPrefix(arr)); // "fl"
    }
}

