package Problem_solving_String;

import java.util.Scanner;

public class ReverseString {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Take input
        System.out.print("Enter a string: ");
        String original = scanner.nextLine();

        // Reverse string manually
        String reversed = "";
        for (int i = 0; i < original.length(); i++) {
            reversed = original.charAt(i) + reversed;
        }

        // Output
        System.out.println("Reversed string: " + reversed);

        scanner.close();
    }
}

