package Problem_solving_String;

public class RemoveSpaces {
    public static String removeSpaces(String str) {
        String result = "";
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) != ' ') {
                result += str.charAt(i);
            }
        }
        return result;
    }

    public static void main(String[] args) {
        System.out.println(removeSpaces("a b c d e")); // "abcde"
    }
}

