package Problem_solving_String;

public class IsDigitOnly {
    public static boolean isDigitsOnly(String str) {
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) < '0' || str.charAt(i) > '9') {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        System.out.println(isDigitsOnly("12345"));   // true
        System.out.println(isDigitsOnly("123a45"));  // false
    }
}

